create
    definer = root@localhost procedure p3(IN x int)
begin
    while x<5 do
        select x;
        set x = x+1;
    end while;
end;

