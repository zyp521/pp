create
    definer = root@localhost procedure p1()
begin
    select now();
    select * from douluo_comment;

end;

