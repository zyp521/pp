create
    definer = root@localhost function f1(x int) returns int
begin
    SET GLOBAL log_bin_trust_function_creators = 1;
    set x = x+1;
    return x;
end;

