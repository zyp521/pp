create
    definer = root@localhost procedure p2(IN x int)
begin
    set x=1;
    if x<5 then
        set x=x+1;
    end if;
    select x as a;

end;

